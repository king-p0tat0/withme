## npm install 목록
### 태훈
npm install chart.js react-chartjs-2

### 서윤
npm install --save @fortawesome/free-solid-svg-icons
npm install --save @fortawesome/fontawesome-svg-core
npm install react-helmet

### 재은
npm install @emotion/react @emotion/styled
npm install —save-dev @babel/core @babel/preset-react @babel/plugin-transform-react-jsx-self @babel/plugin-transform-react-jsx-source
npm install —save-dev eslint @eslint/eslintrc @eslint-community/eslint-utils

### 의영
npm install recharts@2.15.1



### 25.02.11 위에 있는 인스톨 한번에 묶은 명령어
npm install chart.js react-chartjs-2 @fortawesome/free-solid-svg-icons @fortawesome/fontawesome-svg-core react-helmet @emotion/react @emotion/styled @babel/core @babel/preset-react @babel/plugin-transform-react-jsx-self @babel/plugin-transform-react-jsx-source eslint @eslint/eslintrc @eslint-community/eslint-utils recharts@2.15.1 --save-dev

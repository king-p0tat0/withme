package com.javalab.student.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

/**
 * WebSocket 기반 실시간 메시지 전송[미사용]
 * - 클라이언트가 "/app/chat"으로 메시지를 보내면 이 메서드가 호출되어 메시지를 처리하고
 *  "/topic/chat"으로 구독한 클라이언트들에게 메시지를 전송합니다.
 * - 이 컨트롤러는 웹소켓만을 써서 메시지를 송수신하는 경우에 사용되고 현재와 같이
 *   Rest Api 형태로 메시지를 전송하고 중간에 Redis를 사용하여 메시지를 중계하고 또 그 메시지를
 *   Redis Subscriber에서 받아서 WebSocket을 통해 클라이언트에게 전달하는 경우에는 사용하지 않음.
 */
@Controller
@Slf4j
public class ChatController {

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    /**
     * 클라이언트가 "/app/chat"으로 메시지를 보내면 이 메서드가 호출되어 메시지를 처리하고
     * "/topic/chat"으로 구독한 클라이언트들에게 메시지를 전송합니다. 요청 url의 "/app"은 WebSocketConfig에서 설정한 prefix입니다.
     * - @SendTo는 서버가 메시지를 보내는 경로를 지정하고, 클라이언트는 이 경로를 구독하여 해당 메시지를 받을 수 있습니다.
     * - 클라이언트가 /topic/chat 경로를 구독하면, 서버에서 이 경로로 보내는 모든 메시지를 실시간으로 받을 수 있습니다.
     */
//    @MessageMapping("/chat")
//    @SendTo("/topic/chat")  // 이 메시지를 "/topic/chat"으로 구독 중인 클라이언트들에게 보냄
//    public String sendMessage(String message) {
//        // 받은 메시지를 처리하고, "/topic/chat"으로 전송할 메시지 반환
//       log.info("ChatController > sendMessage 받은 메시지: " + message);
//        return message;   // 반환된 메시지는 "/topic/chat" 구독자에게 전송됨
//    }

    /**
     * 특정 사용자의 메시지를 전송할 때 사용하는 메서드
     * 예를 들어, 개인 메시지 전송을 위해 사용
     */
    @MessageMapping("/private")
    public void sendPrivateMessage(String message, String userId) {
        // 특정 사용자에게 개인 메시지를 전송
        messagingTemplate.convertAndSendToUser(userId, "/queue/private", message);
    }
}

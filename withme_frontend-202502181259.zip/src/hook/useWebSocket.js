import { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import { addMessage } from "../redux/messageSlice";
import { showSnackbar } from "../redux/snackbarSlice";
import { Client } from "@stomp/stompjs";
import SockJS from "sockjs-client";
import { SERVER_URL } from "../constant";

const useWebSocket = (user) => {
  const dispatch = useDispatch();
  const stompRef = useRef(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!user?.id) {
      console.warn('⚠️ WebSocket: 사용자 ID가 없습니다. 연결 시도 중단.');
      return;
    }

    const socket = new SockJS(`${SERVER_URL}ws`);
    stompRef.current = new Client({
      webSocketFactory: () => socket,
      debug: (msg) => console.log(`🔍 WebSocket Debug: ${msg}`),
      reconnectDelay: 5000, // 재연결 시도 간격(5초)
      connectHeaders: {
        Authorization: `Bearer ${localStorage.getItem("accessToken")}`, // 토큰 포함
      },

      onConnect: () => {
        console.log(`✅ WebSocket 연결 성공 - 사용자ID: ${user.id}`);
        setConnected(true);

        const topic = `/topic/chat/${user.id}`;
        stompRef.current.subscribe(topic, (message) => {
          try {
            const receivedMessage = JSON.parse(message.body);
            console.log('📩 새 메시지 수신:', receivedMessage);

            // 🔔 메시지 타입에 따른 처리
            if (receivedMessage.messageType === 'answer') {
              dispatch(addMessage(receivedMessage));
              dispatch(showSnackbar({
                message: `📬 새 답변 도착: ${receivedMessage.content}`,
                severity: "success"
              }));
            }
          } catch (error) {
            console.error('🚨 메시지 파싱 오류:', error);
          }
        });
      },

      onStompError: (frame) => {
        console.error("🚨 STOMP 오류 발생:", frame.headers['message']);
      },

      onWebSocketClose: () => {
        console.warn("⚠️ WebSocket 연결 종료됨! 재연결 시도...");
        setConnected(false);
      }
    });

    stompRef.current.activate();

    return () => {
      if (stompRef.current) {
        stompRef.current.deactivate();
        console.log("🔌 WebSocket 연결 해제 완료.");
      }
    };
  }, [user?.id, dispatch]);

  return { client: stompRef.current, connected };
};

export default useWebSocket;

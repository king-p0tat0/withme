import React, { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { fetchWithAuth } from "../../common/fetchWithAuth";
import { API_URL } from "../../constant";
import { setMessages, markMessageAsRead, addMessage } from "../../redux/messageSlice";
import {
  Box,
  List,
  ListItem,
  ListItemText,
  Typography,
  Button,
  CircularProgress,
  TextField,
  Paper,
  Pagination
} from "@mui/material";
import useWebSocket from "../../hook/useWebSocket";
import { showSnackbar } from "../../redux/snackbarSlice";

const DoctorMessageList = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.auth);
  const { messages, loading } = useSelector((state) => state.messages);
  const [replyContent, setReplyContent] = useState("");
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [isReplying, setIsReplying] = useState(false);

  const { connected } = useWebSocket(user);

  const fetchMessagesByPage = useCallback(async (page) => {
    try {
      const response = await fetchWithAuth(`${API_URL}messages/${user.id}?page=${page - 1}&size=10`);
      if (response.ok) {
        const data = await response.json();
        console.log('✅ 메시지 로드 완료:', data.content);
        dispatch(setMessages(data.content));
        setTotalPages(data.totalPages);
      } else {
        console.error('❌ 메시지 로드 실패');
        dispatch(showSnackbar("메시지를 불러오는 데 실패했습니다."));
      }
    } catch (error) {
      console.error('❌ 메시지 로드 중 오류:', error);
      dispatch(showSnackbar("네트워크 오류가 발생했습니다."));
    }
  }, [user.id, dispatch]);

  useEffect(() => {
    fetchMessagesByPage(currentPage);
  }, [fetchMessagesByPage, currentPage]);

  const handleOpenMessage = (message) => {
    setSelectedMessage(message);
    setIsReplying(false);
    if (!message.read) {
      dispatch(markMessageAsRead(message.id));
      fetchWithAuth(`${API_URL}messages/read?messageId=${message.id}`, {
        method: "POST"
      }).catch(error => {
        console.error('메시지 읽음 처리 실패:', error);
        dispatch(showSnackbar("메시지 읽음 처리 중 오류 발생"));
      });
    }
  };

  // 답장 전송 함수
  const handleReply = async () => {
    if (!replyContent.trim()) {
      dispatch(showSnackbar("답장 내용을 입력해주세요."));
      return;
    }

    try {
      const replyMessage = {
        senderId: user.id,
        receiverId: selectedMessage.senderId,
        content: replyContent,
        messageType: "answer",
      };

      const response = await fetchWithAuth(`${API_URL}messages/send`, {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(replyMessage),
      });

      if (response.ok) {
        const newMessage = await response.json();
        dispatch(addMessage(newMessage));
        dispatch(showSnackbar("답변이 성공적으로 전송되었습니다."));

        // ✅ PaidSurveyResultPage로 메시지 데이터 전달
        navigate("/survey/paid/result", { state: { answeredMessage: selectedMessage, answer: replyContent } });

        setReplyContent("");
        setIsReplying(false);
      } else {
        dispatch(showSnackbar("답변 전송에 실패했습니다."));
      }
    } catch (error) {
      console.error('답장 전송 중 오류:', error);
      dispatch(showSnackbar("네트워크 오류로 답장 전송에 실패했습니다."));
    }
  };

  if (loading) return <CircularProgress />;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 100px)', maxWidth: 1200, margin: 'auto' }}>
      <Typography variant="h4" sx={{ mb: 2 }}>받은 메시지 목록</Typography>

      {!connected && (
        <Typography color="error" variant="body2" sx={{ mb: 2 }}>
          🔴 실시간 수신 대기 중...
        </Typography>
      )}

      <Box sx={{ display: 'flex', flexGrow: 1, gap: 2, mb: 2 }}>
        <Paper sx={{ width: '50%', overflowY: 'auto', p: 2 }}>
          {messages.length === 0 ? (
            <Typography variant="body1">받은 메시지가 없습니다.</Typography>
          ) : (
            <List>
              {messages.map((message) => (
                <ListItem
                  key={message.id}
                  button
                  onClick={() => handleOpenMessage(message)}
                  selected={selectedMessage && selectedMessage.id === message.id}
                >
                  <ListItemText
                    primary={`${message.senderName}: ${message.content.substring(0, 50)}...`}
                    secondary={new Date(message.regTime).toLocaleString()}
                    sx={{
                      color: message.read ? "gray" : "blue",
                      '& .MuiListItemText-primary': {
                        fontWeight: message.read ? 'normal' : 'bold'
                      }
                    }}
                  />
                </ListItem>
              ))}
            </List>
          )}
        </Paper>

        <Paper sx={{ width: '50%', p: 2, display: 'flex', flexDirection: 'column' }}>
          {selectedMessage ? (
            <>
              <Typography variant="h6" sx={{ mb: 2 }}>선택된 메시지</Typography>
              <Box sx={{ mb: 2, flexGrow: 1, overflowY: 'auto' }}>
                <Typography variant="body1">{selectedMessage.content}</Typography>
                <Typography variant="caption" sx={{ display: 'block', mt: 1 }}>
                  보낸 사람: {selectedMessage.senderName} |
                  시간: {new Date(selectedMessage.regTime).toLocaleString()}
                </Typography>
              </Box>
              <Button
                variant="contained"
                onClick={() => setIsReplying(true)}
                fullWidth
                sx={{ mb: 2 }}
              >
                답변하기
              </Button>
              {isReplying && (
                <>
                  <TextField
                    multiline
                    rows={4}
                    value={replyContent}
                    onChange={(e) => setReplyContent(e.target.value)}
                    fullWidth
                    placeholder="답장 내용을 입력하세요."
                    sx={{ mb: 2 }}
                  />
                  <Button
                    variant="contained"
                    onClick={handleReply}
                    fullWidth
                  >
                    답장 전송
                  </Button>
                </>
              )}
            </>
          ) : (
            <Typography variant="body1">메시지를 선택하세요.</Typography>
          )}
        </Paper>
      </Box>

      <Pagination
        count={totalPages}
        page={currentPage}
        onChange={(event, value) => setCurrentPage(value)}
        sx={{ mt: 'auto', mb: 2, display: 'flex', justifyContent: 'center' }}
      />
    </Box>
  );
};

export default DoctorMessageList;

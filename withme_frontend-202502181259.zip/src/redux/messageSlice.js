import { createSlice } from '@reduxjs/toolkit';

const messageSlice = createSlice({
  name: 'messages',
  initialState: {
    messages: [],
    loading: false,
    unreadCount: 0,
    latestMessage: null
  },
  reducers: {
    setMessages: (state, action) => {
      state.messages = action.payload;
      state.unreadCount = action.payload.filter(msg => !msg.isRead).length;
    },
    addMessage: (state, action) => {
      // 중복 메시지 방지
      const existingMessage = state.messages.find(
        msg => msg.id === action.payload.id
      );

      if (!existingMessage) {
        state.messages.push(action.payload);
        state.unreadCount += 1;
        state.latestMessage = action.payload;

        // 콘솔 로그 추가
        console.log('🚨 메시지 추가:', action.payload);
        console.log('📬 현재 메시지 목록:', state.messages);
      }
    },
    markMessageAsRead: (state, action) => {
      const message = state.messages.find(msg => msg.id === action.payload);
      if (message) {
        message.read = true;
        state.unreadCount = Math.max(0, state.unreadCount - 1);
      }
    }
  }
});

export const { setMessages, addMessage, markMessageAsRead } = messageSlice.actions;
export default messageSlice.reducer;
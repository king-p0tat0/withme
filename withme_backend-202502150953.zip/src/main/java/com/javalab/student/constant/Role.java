package com.javalab.student.constant;

/**
 * 사용자 권한
 * - 사용자 권한을 정의한 enum 클래스
 */
public enum Role {
    USER, ADMIN, VIP, DOCTOR
}

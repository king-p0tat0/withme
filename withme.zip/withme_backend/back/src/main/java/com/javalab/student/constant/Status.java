package com.javalab.student.constant;



public enum Status {
    PENDING, APPROVED, REJECTED, ON_HOLD
}

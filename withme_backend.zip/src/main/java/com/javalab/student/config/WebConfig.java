package com.javalab.student.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * WebConfig, 환경설정 파일
 * - @Configuration : 이 클래스가 Spring의 설정 파일임을 명시.
 *   프로젝트가 구동될 때 이 클래스를 읽어들여 Bean으로 등록.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    // application.properties 파일에 설정된 값을 가져옵니다.
    @Value("${uploadPath}")
    String uploadPath;  // 예: file:///c:/shop/

    /**
     * CORS (Cross Origin Resource Sharing) 설정
     * - addMapping : CORS를 적용할 URL 패턴. 모든 URL에 대해 적용하려면 /** 설정.
     * - allowedOrigins: 허용할 Origin. 여기서는 React 개발 서버(3000번 포트)만 허용.
     * - allowedMethods: 허용할 HTTP 메서드 설정.
     * - allowedHeaders: 허용할 HTTP 헤더 설정.
     * - allowCredentials: 쿠키를 주고받을 수 있도록 설정.
     * @param registry CORS 매핑 정보를 등록할 객체.
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // 모든 경로에 대해 CORS를 적용.
                .allowedOrigins("http://localhost:3000") // React 개발 서버만 허용.
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // 허용할 HTTP 메서드.
                .allowedHeaders("*") // 모든 헤더를 허용.
                .allowCredentials(true); // 쿠키를 주고받을 수 있도록 설정.
    }

    /**
     * 리소스 핸들러 설정
     * - /images/** 요청이 들어오면 로컬 파일 시스템의 uploadPath로 매핑.
     * - /static-images/** 요청은 프로젝트 내부 클래스 경로에서 제공.
     * @param registry 리소스 핸들러 등록 객체.
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 업로드된 파일을 제공하기 위한 핸들러 설정
        registry.addResourceHandler("/images/**") // URL 요청 패턴: /images/**
                .addResourceLocations(uploadPath); // 로컬 경로 매핑. 예: file:///c:/shop/

        // AWS 환경 관련 리소스 핸들러 주석 유지
        // registry.addResourceHandler("/images/**")
        //     .addResourceLocations("file:///home/ec2-user/shop/chap05_shop_social/build/libs/upload/");

        // 정적 리소스를 제공하기 위한 핸들러 설정
        registry.addResourceHandler("/static-images/**") // URL 요청 패턴: /static-images/**
                .addResourceLocations("classpath:/static/images/"); // 클래스 경로에 있는 정적 리소스
    }
}

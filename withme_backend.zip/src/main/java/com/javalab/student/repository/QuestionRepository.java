package com.javalab.student.repository;

import com.javalab.student.entity.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 📌 Question 엔티티와 데이터베이스 간의 상호작용을 담당하는 리포지토리
 */
@Repository
public interface QuestionRepository extends JpaRepository<Question, Long> {

    /**
     * 특정 주제(category)의 질문을 순서대로 조회
     * @param category 질문 주제
     * @return 질문 리스트
     */
    List<Question> findByCategoryOrderBySequence(String category); // ✅ 메서드가 존재해야 함

    /**
     * 특정 주제(category)와 접근 제한(accessType)에 따른 질문을 순서대로 조회
     * @param category 질문 주제
     * @param accessType 접근 제한 ("FREE" 또는 "PAID")
     * @return 질문 리스트
     */
    List<Question> findByCategoryAndAccessTypeOrderBySequence(String category, Question.AccessType accessType);
}

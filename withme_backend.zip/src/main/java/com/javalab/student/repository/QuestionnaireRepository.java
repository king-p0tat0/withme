package com.javalab.student.repository;

import com.javalab.student.entity.Questionnaire;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Questionnaire 엔티티의 데이터베이스 연동을 처리하는 Repository
 */
@Repository
public interface QuestionnaireRepository extends JpaRepository<Questionnaire, Long> {
}

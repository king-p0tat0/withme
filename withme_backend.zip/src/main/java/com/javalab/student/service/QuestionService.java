package com.javalab.student.service;

import com.javalab.student.dto.QuestionDTO;
import com.javalab.student.entity.Question;
import com.javalab.student.repository.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 📌 문진 질문 관련 비즈니스 로직 처리 서비스 클래스
 */
@Service
public class QuestionService {

    @Autowired
    private QuestionRepository questionRepository;

    /**
     * 📌 특정 카테고리와 사용자 유형에 따라 질문 데이터를 조회
     * @param category 질문 카테고리
     * @param role 사용자 유형 ("FREE" 또는 "PAID")
     * @return 질문 DTO 리스트
     */
    public List<QuestionDTO> getQuestionsByCategoryAndRole(String category, String role) {
        List<Question> questions = "PAID".equalsIgnoreCase(role)
                ? questionRepository.findByCategoryOrderBySequence(category)
                : questionRepository.findByCategoryAndAccessTypeOrderBySequence(category, Question.AccessType.FREE);

        // ✅ 엔티티를 DTO로 변환하여 반환
        return questions.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * 📌 `Question` 엔티티를 `QuestionDTO`로 변환
     * @param question `Question` 엔티티
     * @return `QuestionDTO`
     */
    private QuestionDTO convertToDTO(Question question) {
        return QuestionDTO.builder()
                .id(question.getQuestionId()) // ✅ `getId()` → `getQuestionId()`
                .category(question.getCategory()) // ✅ `getTopic()` → `getCategory()`
                .questionText(question.getQuestionText()) // ✅ `getQuestionText()` 유지
                .choices(question.getChoices().stream()
                        .map(choice -> QuestionDTO.ChoiceDTO.builder()
                                .text(choice.getChoiceText()) // ✅ `getText()` → `getChoiceText()`
                                .score(choice.getScore())
                                .build())
                        .collect(Collectors.toList()))
                .build();
    }
}

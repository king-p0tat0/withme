package com.javalab.student.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.javalab.student.dto.QuestionnaireDTO;
import com.javalab.student.entity.Questionnaire;
import com.javalab.student.repository.QuestionnaireRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * 📌 Questionnaire 관련 비즈니스 로직을 처리하는 서비스 클래스
 */
@Service
@RequiredArgsConstructor
public class QuestionnaireService {

    private final QuestionnaireRepository questionnaireRepository;
    private final ObjectMapper objectMapper;

    /**
     * 📌 문진 결과를 저장하고 DTO로 변환
     * @param username 사용자 이름 (✅ 기존 userId → username으로 변경)
     * @param answers 문진 답변 (JSON 형식)
     * @param totalScore 총 점수
     * @return 저장된 문진 결과 DTO
     */
    public QuestionnaireDTO saveQuestionnaire(String username, Object answers, int totalScore) throws JsonProcessingException {
        // ✅ Questionnaire 객체 생성 (`userId` → `username`으로 변경)
        Questionnaire questionnaire = Questionnaire.builder()
                .username(username) // ✅ `.userId(userId)` → `.username(username)`
                .answers(objectMapper.writeValueAsString(answers)) // JSON 변환
                .totalScore(totalScore)
                .submittedAt(LocalDateTime.now()) // 현재 시간 저장
                .build();

        // ✅ 데이터베이스에 저장
        Questionnaire savedQuestionnaire = questionnaireRepository.save(questionnaire);

        // ✅ DTO로 변환하여 반환
        return QuestionnaireDTO.builder()
                .questionnaireId(savedQuestionnaire.getQuestionnaireId()) // ✅ `id` → `questionnaireId`
                .username(savedQuestionnaire.getUsername()) // ✅ `userId` → `username`
                .answers(savedQuestionnaire.getAnswers())
                .totalScore(savedQuestionnaire.getTotalScore())
                .submittedAt(savedQuestionnaire.getSubmittedAt())
                .build();
    }
}

package com.javalab.student.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * 📌 문진 결과 엔티티
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "questionnaire")
public class Questionnaire {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long questionnaireId; // ✅ `id` → `questionnaireId`

    @Column(nullable = false)
    private String username; // ✅ 기존 `userId` → `username`으로 변경

    @Column(nullable = false, length = 2000)
    private String answers; // 문진 답변 (JSON 형식으로 저장)

    @Column(nullable = false)
    private int totalScore; // 총 점수

    @Column(nullable = false)
    private LocalDateTime submittedAt; // 제출 시간
}

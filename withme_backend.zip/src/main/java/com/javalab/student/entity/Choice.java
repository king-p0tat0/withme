package com.javalab.student.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * 📌 문진 선택지 엔티티
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "choice") // ✅ 테이블명과 일치
public class Choice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "choice_id")
    private Long choiceId; // ✅ 컬럼명과 일치하도록 수정

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "question_id", nullable = false) // ✅ FK 설정
    private Question question; // ✅ Question과 N:1 관계 설정

    @Column(nullable = false)
    private String choiceText; // ✅ `text` → `choiceText`로 변경

    @Column(nullable = false)
    private Integer choiceValue; // ✅ 선택지 값 (1~5 등)

    @Column(nullable = false)
    private Integer score; // ✅ 선택지 점수 (5~1)
}

package com.javalab.student.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

/**
 * 📌 문진 질문 엔티티 클래스
 * - 주제(category), 질문 내용(questionText), 선택지(choices), 접근 제한(accessType) 포함
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "question") // ✅ 테이블명 DB와 일치하도록 설정
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "question_id") // ✅ DB 컬럼명과 일치하도록 명시
    private Long questionId; // ✅ 필드명 `questionId`로 변경하여 DB 컬럼과 일치

    @Column(nullable = false)
    private String category; // ✅ 기존 `topic` → `category`로 수정하여 DB 컬럼과 매칭

    @Column(name = "question_text", nullable = false) // ✅ DB 컬럼명과 일치
    private String questionText;

    /**
     * ✅ 선택지 리스트
     * - `question_id`를 FK로 사용하여 `choice` 테이블과 연결됨
     * - 질문 삭제 시 선택지도 함께 삭제 (`cascade = CascadeType.ALL`)
     */
    @OneToMany(mappedBy = "question", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<Choice> choices; // ✅ `Choice` 엔티티와 관계 설정

    @Column(nullable = false)
    private int sequence; // ✅ 질문 순서

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AccessType accessType; // ✅ 접근 제한 (FREE 또는 PAID)

    /**
     * ✅ 접근 제한 유형을 나타내는 ENUM
     */
    public enum AccessType {
        FREE, PAID
    }
}

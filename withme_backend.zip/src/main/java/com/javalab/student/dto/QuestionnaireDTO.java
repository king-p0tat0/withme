package com.javalab.student.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 📌 문진 결과 DTO 클래스
 */
@Data
@Builder
public class QuestionnaireDTO {
    private Long questionnaireId; // ✅ `id` → `questionnaireId`
    private String username; // ✅ `userId` → `username`
    private String answers;
    private int totalScore;
    private LocalDateTime submittedAt;
}

package com.javalab.student.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * 📌 Question DTO 클래스
 * - 엔티티 데이터를 클라이언트에 전달하는 역할
 */
@Data
@Builder
public class QuestionDTO {
    private Long id; // ✅ 기존 `questionId`에서 변경 가능
    private String category; // ✅ 기존 `topic` → `category`
    private String questionText; // ✅ DB 필드명과 일치
    private List<ChoiceDTO> choices; // ✅ 선택지 리스트

    /**
     * 📌 선택지 DTO
     */
    @Data
    @Builder
    public static class ChoiceDTO {
        private String text;
        private int score;
    }
}

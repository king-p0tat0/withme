package com.javalab.student.controller;

import com.javalab.student.dto.QuestionDTO;
import com.javalab.student.service.QuestionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 📌 API 요청을 처리하는 컨트롤러
 * - 회원 유형에 따라 질문을 필터링하여 클라이언트에게 제공
 */
@RestController
@RequestMapping("/api/questions")
@RequiredArgsConstructor
public class QuestionController {

    private final QuestionService questionService;

    /**
     * 📌 특정 주제(category)와 사용자 유형(role)에 맞는 질문 목록을 조회
     *
     * 🔹 요청 예시:
     *   GET /api/questions/소화 건강?role=FREE
     *   GET /api/questions/피부 건강?role=PAID
     *
     * @param category 주제 (예: "소화 건강")
     * @param role 사용자 유형 (FREE, PAID)
     * @return 질문 리스트 (QuestionDTO)
     */
    @GetMapping("/{category}") // ✅ URL 변수명 topic → category로 변경
    public ResponseEntity<List<QuestionDTO>> getQuestions(
            @PathVariable(name = "category") String category, // 🔹 변수명 명시
            @RequestParam(name = "role") String role // 🔹 변수명 명시
    ) {
        // 특정 주제(category)와 사용자 유형(role)에 따라 질문 조회
        List<QuestionDTO> questions = questionService.getQuestionsByCategoryAndRole(category, role);

        // 결과가 없을 경우 204 No Content 반환
        if (questions.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        // 조회된 질문 리스트를 200 OK로 반환
        return ResponseEntity.ok(questions);
    }
}

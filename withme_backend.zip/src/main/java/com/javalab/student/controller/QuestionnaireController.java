package com.javalab.student.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.javalab.student.dto.QuestionDTO;
import com.javalab.student.dto.QuestionnaireDTO;
import com.javalab.student.service.QuestionService; // ✅ 추가
import com.javalab.student.service.QuestionnaireService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 📌 문진(Questionnaire) 관련 API 요청을 처리하는 컨트롤러
 */
@RestController
@RequestMapping("/api/questionnaire")
@RequiredArgsConstructor
public class QuestionnaireController {

    private final QuestionnaireService questionnaireService;
    private final QuestionService questionService; // ✅ 추가

    /**
     * 📌 특정 카테고리(category)와 사용자 유형(role)에 맞는 질문 목록을 조회
     *
     * 🔹 요청 예시:
     *   GET /api/questionnaire/소화 건강?role=FREE
     *   GET /api/questionnaire/피부 건강?role=PAID
     *
     * @param category 질문 카테고리 (예: "소화 건강")
     * @param role 사용자 유형 (FREE, PAID)
     * @return 질문 리스트 (QuestionDTO)
     */
    @GetMapping("/{category}") // ✅ 기존 topic → category로 변경
    public ResponseEntity<List<QuestionDTO>> getQuestions(
            @PathVariable String category,
            @RequestParam String role
    ) {
        List<QuestionDTO> questions = questionService.getQuestionsByCategoryAndRole(category, role);
        if (questions.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(questions);
    }
}

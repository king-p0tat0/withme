import React from "react";
import "../styles/ProgressBar.css";

/**
 * 진행 상태를 시각적으로 보여주는 컴포넌트
 * @param {number} current - 현재 질문 번호
 * @param {number} total - 전체 질문 개수
 */
const ProgressBar = ({ current, total }) => {
  const progress = (current / total) * 100; // 진행률 계산 (백분율)

  return (
    <div className="progress-bar">
      <div className="progress" style={{ width: `${progress}%` }}></div>
    </div>
  );
};

export default ProgressBar;

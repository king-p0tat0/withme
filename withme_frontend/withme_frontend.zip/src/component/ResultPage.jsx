import React from "react";
import { Bar } from "react-chartjs-2";
import "chart.js/auto";

/**
 * 문진 겨로가 페이지 컴포넌트
 * @param {number} totalScore - 총점
 * @param {object} analysis - 주제별 점수 분석 데이터
 */

 const ResultPage = ({ totalScore, analysis }) => {
     const chartData = {
         labels: Object.keys(analysis), // 주제이름
         datasets: [
             {
                 label: "Scores by Topic", // 그래프 레이블
                 data: Object.values(analysis), // 각 주제의 점수
                 backgroundColor: "rgba(75, 192, 192 0.6)", // 그래프 색상
                 },
             ],
         };
     return (
         <div>
             <h2>총점 : {totalScore} </h2>
             <div style = {{ width: "80%", margin: "20px auto"}}>
                 <Bar data = {chartData} /> {/* 차트 표시 */}
             </div>
         </div>
         );
     };

 export default ResultPage;
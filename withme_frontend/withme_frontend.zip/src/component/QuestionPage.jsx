import React, { useState, useEffect } from "react";
import api from "../api/api";
import ProgressBar from "./ProgressBar";
import "../styles/QuestionPage.css";

const QuestionPage = ({ category, role, onComplete }) => {
  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);
    api
      .get(`/questions/${category}?role=${role}`)
      .then((response) => {
        console.log("✅ 질문 데이터:", response.data);
        setQuestions(response.data);
        setError(null);
      })
      .catch((error) => {
        console.error("🚨 질문 데이터를 불러오는데 실패:", error);
        console.error("🔍 오류 응답:", error.response); // 서버 응답을 확인
        console.error("🔍 상태 코드:", error.response?.status);
        console.error("🔍 오류 메시지:", error.message);
        setError(`질문 데이터를 가져오는 데 문제가 발생했습니다. (오류 코드: ${error.response?.status})`);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [category, role]);


  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;
  if (!questions.length) return <p>질문 데이터가 없습니다.</p>;

  const currentQuestion = questions[currentIndex];

  return (
    <div className="question-page">
      <ProgressBar current={currentIndex + 1} total={questions.length} />
      <h2>{currentQuestion.questionText}</h2>
      <div className="choices">
        {currentQuestion.choices.map((choice, index) => (
          <button
            key={index}
            onClick={() => setAnswers({ ...answers, [currentQuestion.questionId]: choice })}
            className={answers[currentQuestion.questionId]?.text === choice.text ? "selected" : ""}
          >
            {choice.text}
          </button>
        ))}
      </div>
      <div className="navigation">
        <button onClick={() => setCurrentIndex(currentIndex - 1)} disabled={currentIndex === 0}>
          이전
        </button>
        <button onClick={() => setCurrentIndex(currentIndex + 1)}>
          {currentIndex === questions.length - 1 ? "완료" : "다음"}
        </button>
      </div>
    </div>
  );
};

export default QuestionPage;

import { createRoot } from 'react-dom/client' // React DOM 렌더링을 위한 함수
import './index.css' // 전역 스타일
import App from './App.jsx' // 메인 애플리케이션 컴포넌트
import { BrowserRouter } from 'react-router-dom' // React 라우팅을 지원하는 컴포넌트

/**
 * 리액트 앱이 시작되는 지점으로 App 컴포넌트를 렌더링한다.
 * - 'createRoot'를 사용해 DOM에 React 앱을 마운트
 * - App 컴포넌트를 BrowserRouter로 감싸 라우팅 기능을 사용할 수 있도록 한다.
 */
createRoot(document.getElementById('root')).render(
    <BrowserRouter>
        <App /> {/* 메인 애플리케이션 */}
    </BrowserRouter>
);

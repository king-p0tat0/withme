import React from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import QuestionPage from "./component/QuestionPage.jsx";
import "./App.css";

/**
 * MainPage 컴포넌트: 테스트 페이지를 구성하는 컴포넌트
 */
const MainPage = () => {
  const navigate = useNavigate();

  return (
    <div>
      <h1>테스트용 메인 페이지</h1>
      <button onClick={() => navigate("/questions/health")}>문진 검사 시작</button>
    </div>
  );
};

/**
 * App 컴포넌트: 라우팅 설정
 */
const App = () => {
  return (
    <Routes>
      <Route path="/" element={<MainPage />} />
      <Route
        path="/questions/:topic"
        element={<QuestionPage topic="health" role="FREE" onComplete={() => {}} />}
      />
    </Routes>
  );
};

export default App;

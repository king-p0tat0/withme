package com.javalab.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
